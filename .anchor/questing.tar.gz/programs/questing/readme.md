# Play to Earn Questing Program

# Summary
Offer versatile staking for projects who wish to yield new tokens from interactions.

# Security
Please report vulnerabilities to `dominic.m.digiacomo@gmail.com`. You will be compensated for your findings and contributions to the source code at the [GitHub Project](https://github.com/whymidnight/solana-p2e-questing-game).
