pub const QUEST_PDA_SEED: &[u8] = b"questing";
pub const QUEST_ORACLE_SEED: &[u8] = b"oracle";
pub const QUEST_REWARD_SEED: &[u8] = b"quest_reward";
pub const QUEST_RECORDER: &[u8] = b"quest_recorder";
