pub const SWAP_PDA_SEED: &[u8] = b"swaping";
pub const SWAP_ORACLE_SEED: &[u8] = b"oracle";
pub const SWAP_REWARD_SEED: &[u8] = b"swap_reward";
pub const SWAP_RECORDER: &[u8] = b"swap_recorder";
