# NOTES

# StartQuest

### Remaining Accounts
```
[
    (OPT) tender_mint,
    (OPT) tender_token_account,
    (OPT) tendersplit_token_account_n0,
    (OPT) tendersplit_token_account_n1,
    (OPT) tendersplit_token_account_n2,
]
```
